
# B2C2 endpoints
B2C2_INSTRUMENTS_ENDPOINT = '/instruments/'
B2C2_REQUEST_FOR_QUOTE_ENDPOINT = '/request_for_quote/'
B2C2_TRADE_ENDPOINT = '/order/'
B2C2_BALANCE_ENDPOINT = '/balance/'
B2C2_CURRENCY_ENDPOINT = '/currency/'
